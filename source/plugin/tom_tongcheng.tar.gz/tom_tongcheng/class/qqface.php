<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$qqface = array(
	'΢Ц' => array('background-position' => 'background-position: left 0;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/100.gif'),
	'Ʋ��' => array('background-position' => 'background-position: left -29px;;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/101.gif'),
	'ɫ' => array('background-position' => 'background-position: left -58px;;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/102.gif'),
	'����' => array('background-position' => 'background-position: left -87px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/103.gif'),
	'����' => array('background-position' => 'background-position: left -116px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/104.gif'),
	'����' => array('background-position' => 'background-position: left -145px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/105.gif'),
	'����' => array('background-position' => 'background-position: left -174px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/106.gif'),
	'����' => array('background-position' => 'background-position: left -203px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/107.gif'),
	'˯' => array('background-position' => 'background-position: left -232px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/108.gif'),
	'���' => array('background-position' => 'background-position: left -261px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/109.gif'),
	'����' => array('background-position' => 'background-position: left -290px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/110.gif'),
	'��ŭ' => array('background-position' => 'background-position: left -319px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/111.gif'),
	'��Ƥ' => array('background-position' => 'background-position: left -348px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/112.gif'),
	'����' => array('background-position' => 'background-position: left -377px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/113.gif'),
	'����' => array('background-position' => 'background-position: left -406px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/114.gif'),
	'�ѹ�' => array('background-position' => 'background-position: left -435px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/115.gif'),
	'��' => array('background-position' => 'background-position: left -464px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/116.gif'),
	'�亹' => array('background-position' => 'background-position: left -493px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/117.gif'),
	'ץ��' => array('background-position' => 'background-position: left -522px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/118.gif'),
	'��' => array('background-position' => 'background-position: left -551px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/119.gif'),
	'͵Ц' => array('background-position' => 'background-position: left -580px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/120.gif'),
	'�ɰ�' => array('background-position' => 'background-position: left -609px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/121.gif'),
	'����' => array('background-position' => 'background-position: left -638px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/122.gif'),
	'����' => array('background-position' => 'background-position: left -667px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/123.gif'),
	'����' => array('background-position' => 'background-position: left -696px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/124.gif'),
	'��' => array('background-position' => 'background-position: left -725px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/125.gif'),
	'����' => array('background-position' => 'background-position: left -754px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/126.gif'),
	'����' => array('background-position' => 'background-position: left -783px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/127.gif'),
	'��Ц' => array('background-position' => 'background-position: left -812px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/128.gif'),
	'���' => array('background-position' => 'background-position: left -841px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/129.gif'),
	'�ܶ�' => array('background-position' => 'background-position: left -870px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/130.gif'),
	'����' => array('background-position' => 'background-position: left -899px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/131.gif'),
	'����' => array('background-position' => 'background-position: left -928px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/132.gif'),
	'��' => array('background-position' => 'background-position: left -957px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/133.gif'),
	'��' => array('background-position' => 'background-position: left -986px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/134.gif'),
	'��ĥ' => array('background-position' => 'background-position: left -1015px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/135.gif'),
	'��' => array('background-position' => 'background-position: left -1044px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/136.gif'),
	'����' => array('background-position' => 'background-position: left -1073px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/137.gif'),
	'�ô�' => array('background-position' => 'background-position: left -1102px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/138.gif'),
	'�ټ�' => array('background-position' => 'background-position: left -1131px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/139.gif'),
	'����' => array('background-position' => 'background-position: left -1160px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/140.gif'),
	'�ٱ�' => array('background-position' => 'background-position: left -1189px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/141.gif'),
	'����' => array('background-position' => 'background-position: left -1218px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/142.gif'),
	'�ܴ���' => array('background-position' => 'background-position: left -1247px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/143.gif'),
	'��Ц' => array('background-position' => 'background-position: left -1276px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/144.gif'),
	'��ߺ�' => array('background-position' => 'background-position: left -1305px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/145.gif'),
	'�Һߺ�' => array('background-position' => 'background-position: left -1334px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/146.gif'),
	'��Ƿ' => array('background-position' => 'background-position: left -1363px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/147.gif'),
	'����' => array('background-position' => 'background-position: left -1392px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/148.gif'),
	'ί��' => array('background-position' => 'background-position: left -1421px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/149.gif'),
	'�����' => array('background-position' => 'background-position: left -1450px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/150.gif'),
	'����' => array('background-position' => 'background-position: left -1479px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/151.gif'),
	'����' => array('background-position' => 'background-position: left -1508px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/152.gif'),
	'��' => array('background-position' => 'background-position: left -1537px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/153.gif'),
	'����' => array('background-position' => 'background-position: left -1566px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/154.gif'),
	'�˵�' => array('background-position' => 'background-position: left -1595px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/155.gif'),
	'����' => array('background-position' => 'background-position: left -1624px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/156.gif'),
	'ơ��' => array('background-position' => 'background-position: left -1653px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/157.gif'),
	'����' => array('background-position' => 'background-position: left -1682px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/158.gif'),
	'ƹ��' => array('background-position' => 'background-position: left -1711px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/159.gif'),
	'����' => array('background-position' => 'background-position: left -1740px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/160.gif'),
	'��' => array('background-position' => 'background-position: left -1769px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/161.gif'),
	'��ͷ' => array('background-position' => 'background-position: left -1798px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/162.gif'),
	'õ��' => array('background-position' => 'background-position: left -1827px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/163.gif'),
	'��л' => array('background-position' => 'background-position: left -1856px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/164.gif'),
	'ʾ��' => array('background-position' => 'background-position: left -1885px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/165.gif'),
	'����' => array('background-position' => 'background-position: left -1914px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/166.gif'),
	'����' => array('background-position' => 'background-position: left -1943px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/167.gif'),
	'����' => array('background-position' => 'background-position: left -1972px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/168.gif'),
	'����' => array('background-position' => 'background-position: left -2001px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/169.gif'),
	'ը��' => array('background-position' => 'background-position: left -2030px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/170.gif'),
	'��' => array('background-position' => 'background-position: left -2059px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/171.gif'),
	'����' => array('background-position' => 'background-position: left -2088px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/172.gif'),
	'ư��' => array('background-position' => 'background-position: left -2117px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/173.gif'),
	'���' => array('background-position' => 'background-position: left -2146px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/174.gif'),
	'����' => array('background-position' => 'background-position: left -2175px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/175.gif'),
	'̫��' => array('background-position' => 'background-position: left -2204px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/176.gif'),
	'����' => array('background-position' => 'background-position: left -2233px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/177.gif'),
	'ӵ��' => array('background-position' => 'background-position: left -2262px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/178.gif'),
	'ǿ' => array('background-position' => 'background-position: left -2291px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/179.gif'),
	'��' => array('background-position' => 'background-position: left -2320px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/180.gif'),
	'����' => array('background-position' => 'background-position: left -2349px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/181.gif'),
	'ʤ��' => array('background-position' => 'background-position: left  -2378px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/182.gif'),
	'��ȭ' => array('background-position' => 'background-position: left -2407px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/183.gif'),
	'����' => array('background-position' => 'background-position: left -2436px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/184.gif'),
	'ȭͷ' => array('background-position' => 'background-position: left -2465px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/185.gif'),
	'�' => array('background-position' => 'background-position: left -2494px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/186.gif'),
	'����' => array('background-position' => 'background-position: left -2523px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/187.gif'),
	'no' => array('background-position' => 'background-position: left -2552px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/188.gif'),
	'ok' => array('background-position' => 'background-position: left -2581px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/189.gif'),
	'����' => array('background-position' => 'background-position: left -2610px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/190.gif'),
	'����' => array('background-position' => 'background-position: left -2639px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/191.gif'),
	'����' => array('background-position' => 'background-position: left -2668px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/192.gif'),
	'����' => array('background-position' => 'background-position: left -2697px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/193.gif'),
	'���' => array('background-position' => 'background-position: left -2726px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/194.gif'),
	'תȦ' => array('background-position' => 'background-position: left -2755px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/195.gif'),
	'��ͷ' => array('background-position' => 'background-position: left -2784px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/196.gif'),
	'��ͷ' => array('background-position' => 'background-position: left -2813px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/197.gif'),
	'����' => array('background-position' => 'background-position: left -2842px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/198.gif'),
	'����' => array('background-position' => 'background-position: left -2871px;', 'src' => 'source/plugin/tom_tongcheng/images/pinglun/199.gif'),
);

if (CHARSET == 'utf-8') {
	$qqface = qqface_iconv($qqface,'gbk','utf-8');
}

function qqface_replace($string){
	global $qqface;
	
	if(is_array($qqface) && !empty($qqface)){
		foreach($qqface as $key => $value){
			$string = str_replace('['.$key.']', '<img src="'.$value['src'].'" />', $string);
		}
		return $string;
	}else{
		return false;
	}
	return false;
}

function qqface_iconv($data, $in_charset, $out_charset) {
    $arr = array();
	if(is_array($data)) {
        foreach($data AS $key => $val) {
            $key = diconv($key, $in_charset, $out_charset);
			$arr[$key] = $val;
        }
    } 
    return $arr;
}