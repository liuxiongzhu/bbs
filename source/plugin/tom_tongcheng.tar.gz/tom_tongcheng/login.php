<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$__UserInfo = array();
$userStatus = false;
$loginStatus = 0;
$pmNewNum = 0;

$mustLogin = true;
if($_GET['id'] == 'tom_tongcheng' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'list' || $_GET['mod'] == 'info' || $_GET['mod'] == 'home')){
    $mustLogin = false;
}
if($_GET['id'] == 'tom_tcshop' && ($_GET['mod'] == 'index' || $_GET['mod'] == 'list' || $_GET['mod'] == 'search' || $_GET['mod'] == 'details')){
    $mustLogin = false;
}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
    $mustLogin = true;
}

$cookieOpenid = getcookie('tom_tongcheng_user_openid');
if(!empty($cookieOpenid)){
    $__UserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($cookieOpenid);
    if($__UserInfo && !empty($__UserInfo['openid'])){
        $userStatus = true;
        $mustLogin = true;
    }
}

if($mustLogin){
    $loginStatus = 1;

    if(!$userStatus){
        $openid     = '';
        $nickname   = '';
        $headimgurl = '';
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/oauth3.php';
        $nickname = diconv($nickname,'utf-8');
        $__UserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($openid);
        if($__UserInfo){
            if(strpos($__UserInfo['picurl'], 'wx.qlogo.cn') !== FALSE){
                $updateData = array();
                //$updateData['nickname']   = $nickname;
                $updateData['picurl']     = $headimgurl;
                C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
            }
            $lifeTime = 86400;
            dsetcookie('tom_tongcheng_user_openid',$openid,$lifeTime);
        }else{
            $insertData = array();
            $insertData['openid']      = $openid;
            $insertData['nickname']    = $nickname;
            $insertData['picurl']      = $headimgurl;
            $insertData['add_time']    = TIMESTAMP;
            if(C::t('#tom_tongcheng#tom_tongcheng_user')->insert($insertData)){
                $__UserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($openid);
                $lifeTime = 86400;
                dsetcookie('tom_tongcheng_user_openid',$openid,$lifeTime);
            }
        }
    }

    $pmNewNum = C::t('#tom_tongcheng#tom_tongcheng_pm')->fetch_all_newnum(" AND user_id={$__UserInfo['id']} ");
    $noReadTzCount = C::t('#tom_tongcheng#tom_tongcheng_tz')->fetch_all_count(" AND user_id='{$__UserInfo['id']}' AND is_read=0 ");
    $pmNewNum = $pmNewNum + $noReadTzCount;

    $__UserInfo['groupid'] = 0;
    $__UserInfo['groupsiteid'] = 0;
    if($tongchengConfig['manage_user_id'] == $__UserInfo['id']){
        $__UserInfo['groupid'] = 1;
    }
    if($__UserInfo['groupid'] == 0){
        $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_manage_user_id($__UserInfo['id']);
        if($siteInfoTmp){
            $tcadminfilename = DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php';
            if(file_exists($tcadminfilename)){
                $__UserInfo['groupid'] = 2;
                $__UserInfo['groupsiteid'] = $siteInfoTmp['id'];
            }
        }
    }

    if($__UserInfo['status'] == 2 && $_GET['mod'] != 'personal' && $_GET['mod'] != 'article'){
        dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=personal");exit;
    }
}


