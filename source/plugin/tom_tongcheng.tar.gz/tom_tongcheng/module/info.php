<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.cn
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tongcheng_id = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;

$tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);

if(!$tongchengInfo){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=index");exit;
}

if($tongchengInfo['shenhe_status'] != 1){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=mylist&type=4");exit;
}

$open_edit_pinglun = 0;
if($tongchengInfo['user_id'] == $__UserInfo['id'] && $tongchengConfig['open_fbr_remove_pinglun'] == 1){
    $open_edit_pinglun = 1;
}else if($__UserInfo['groupid'] == 1 && $site_id == 1){
    $open_edit_pinglun = 1;
}else if($__UserInfo['groupid'] == 2 && $site_id == $__UserInfo['groupsiteid']){
    $open_edit_pinglun = 1;
}

$content = contentFormat($tongchengInfo['content']);
$contentTmp = strip_tags($content);
$contentTmp = str_replace("\r\n","",$contentTmp);
$contentTmp = str_replace("\n","",$contentTmp);
$contentTmp = str_replace("\r","",$contentTmp);

$content = str_replace("\r\n","<br/>",$content);
$content = str_replace("\n","<br/>",$content);
$content = str_replace("\r","<br/>",$content);

$title = cutstr($contentTmp,20,"...");
$desc = cutstr($contentTmp,80,"...");
if(empty($tongchengInfo['title'])){
    $tongchengInfo['title'] = cutstr($contentTmp,50,"...");
}
if($tongchengConfig['open_fabu_title'] == 0){
    $tongchengInfo['title'] = cutstr($contentTmp,50,"...");
}

$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengInfo['user_id']); 
$modelInfo = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($tongchengInfo['model_id']);
$typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
$cateInfo = array();
if($tongchengInfo['cate_id'] > 0){
    $cateInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_cate')->fetch_by_id($tongchengInfo['cate_id']);
    if($cateInfoTmp){
        $cateInfo = $cateInfoTmp;
    }
}
$siteInfo = array('id'=>1,'name'=>$tongchengConfig['plugin_name']);
if($tongchengInfo['site_id'] > 1){
    $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tongchengInfo['site_id']);
}

$attrList = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY id DESC ",0,50);
$tagList = C::t('#tom_tongcheng#tom_tongcheng_tag')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY id DESC ",0,50);
$photoListTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY id ASC ",0,50);
$photoList = array();
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach ($photoListTmp as $kk => $vv){
        if(!preg_match('/^http/', $vv['picurl']) ){
            $picurl = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
        }else{
            $picurl = $vv['picurl'];
        }
        $photoList[$kk] = $picurl;
    }
}
$photoListStr = implode('|', $photoList);

$modelListTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list(" "," ORDER BY paixu ASC,id DESC ",0,50);
    
$modelList = array();
$i = 1;
$modelCount = 0;
if(is_array($modelListTmp) && !empty($modelListTmp)){
    foreach ($modelListTmp as $key => $value){
        $modelList[$key] = $value;
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_tongcheng/') === FALSE){
                $picurl = (preg_match('/^http:/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $modelList[$key]['picurl'] = $picurl;
        $modelList[$key]['i'] = $i;
        $i++;
        $modelCount++;
    }
}
$tcCount = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_count(" AND user_id={$userInfo['id']} AND status=1 ");
DB::query("UPDATE ".DB::table('tom_tongcheng')." SET clicks=clicks+1 WHERE id='$tongcheng_id' ", 'UNBUFFERED');

$pinglunListTmp = C::t('#tom_tongcheng#tom_tongcheng_pinglun')->fetch_all_list(" AND tongcheng_id = {$tongchengInfo['id']} ", 'ORDER BY ping_time DESC,id DESC', 0, 5);
$pinglunList = array();
if(is_array($pinglunListTmp) && !empty($pinglunListTmp)){
    foreach($pinglunListTmp as $key => $value){
        $pinglunList[$key] = $value;
        $pinglunList[$key]['content'] = qqface_replace(dhtmlspecialchars($value['content']));
        $pinglunList[$key]['userInfo'] = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $pinglunList[$key]['reply_list'] = '';
        $replyListTmp = C::t('#tom_tongcheng#tom_tongcheng_pinglun_reply')->fetch_all_list(" AND tongcheng_id = {$tongchengInfo['id']} AND ping_id = {$value['id']} ", "ORDER BY reply_time ASC,id ASC", 0, 1000);
        if(is_array($replyListTmp) && !empty($replyListTmp)){
            foreach($replyListTmp as $k => $v){
                if($tongchengInfo['user_id'] == $v['reply_user_id']){
                    $pinglunList[$key]['reply_list'].= '<div class="comment-item-content-text" id="comment-item-content-text_'.$v['id'].'"><span>'.$v['reply_user_nickname'].'&nbsp;<span class="floor_main">'.lang('plugin/tom_tongcheng', 'info_pinglun_floor_main').'</span>'.lang('plugin/tom_tongcheng','pinglun_hueifu_dian').'&nbsp;</span>'.qqface_replace(dhtmlspecialchars($v['content'])).'&nbsp;&nbsp;<span class="remove" onClick="removeReply('.$v['id'].');">'.lang('plugin/tom_tongcheng','info_comment_del').'</span></div>'; 
                }else{
                    $pinglunList[$key]['reply_list'].= '<div class="comment-item-content-text" id="comment-item-content-text_'.$v['id'].'"><span>'.$v['reply_user_nickname'].lang('plugin/tom_tongcheng','pinglun_hueifu_dian').'&nbsp;</span>'.qqface_replace(dhtmlspecialchars($v['content'])).'&nbsp;&nbsp;<span class="remove" onClick="removeReply('.$v['id'].');">'.lang('plugin/tom_tongcheng','info_comment_del').'</span></div>'; 
                }
            }  
        }
    }
}
$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=info&tongcheng_id=".$tongcheng_id;
$shareLogo  = $userInfo['picurl'];
if(is_array($photoList) && !empty($photoList) && !empty($photoList[0])){
    $shareLogo = $photoList[0];
}

$isCollect = 0;
if($__UserInfo){
    $collectListTmp = C::t('#tom_tongcheng#tom_tongcheng_collect')->fetch_all_list(" AND user_id={$__UserInfo['id']} AND tongcheng_id={$tongcheng_id} "," ORDER BY id DESC ",0,1);
    if(is_array($collectListTmp) && !empty($collectListTmp)){
        $isCollect = 1;
    }
}

if($__ShowTcshop == 1){
    $ajaxLoadShopListUrl = "plugin.php?id=tom_tcshop:ajax&site={$site_id}&act=list&user_id={$userInfo['id']}&formhash=".$formhash;
}

$infoShareTitle = str_replace("{TITLE}",$tongchengInfo['title'], $typeInfo['info_share_title']);
$infoShareDesc = str_replace("{TITLE}",$tongchengInfo['title'], $typeInfo['info_share_desc']);
$infoShareTitle = str_replace("{SITENAME}",$__SitesInfo['name'], $infoShareTitle);
$infoShareDesc = str_replace("{SITENAME}",$__SitesInfo['name'], $infoShareDesc);
if(!empty($cateInfo)){
    $infoShareTitle = str_replace("{CATENAME}",$cateInfo['name'], $infoShareTitle);
    $infoShareDesc = str_replace("{CATENAME}",$cateInfo['name'], $infoShareDesc);
}
if(is_array($attrList) && !empty($attrList)){
    foreach ($attrList as $key => $value){
        $value['value'] = str_replace(" ",'|', $value['value']);
        $infoShareTitle = str_replace("{ATTR".$value['attr_id']."}",$value['value'], $infoShareTitle);
        $infoShareDesc = str_replace("{ATTR".$value['attr_id']."}",$value['value'], $infoShareDesc);
    }
}
$infoShareTitle = str_replace(" ",'', $infoShareTitle);
$infoShareDesc = str_replace(" ",'', $infoShareDesc);
$shareTitle = lang("plugin/tom_tongcheng", "kuohao_left")."{$typeInfo['name']}".lang("plugin/tom_tongcheng", "kuohao_right")."{$tongchengInfo['title']}-{$__SitesInfo['name']}";
$shareDesc = $desc;
if(!empty($infoShareTitle)){
    $shareTitle = $infoShareTitle;
}
if(!empty($infoShareDesc)){
    $shareDesc = $infoShareDesc;
}

$messageUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=message&act=create&tongcheng_id=".$tongchengInfo['id'].'&to_user_id='.$userInfo['id'].'&formhash='.FORMHASH;
$tousuUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=tousu&tongcheng_id=".$tongchengInfo['id'];
$addPinglunUrl = "plugin.php?id=tom_tongcheng:ajax&act=pinglun&formhash=".FORMHASH;
$showPinglunUrl = "plugin.php?id=tom_tongcheng:ajax&act=loadPinglun&tongcheng_id={$tongchengInfo['id']}&formhash=".FORMHASH;
$removePinglunUrl = "plugin.php?id=tom_tongcheng:ajax&act=removePinglun&tongcheng_id={$tongchengInfo['id']}&formhash=".FORMHASH;
$removeReplyUrl = "plugin.php?id=tom_tongcheng:ajax&act=removeReplyPinglun&tongcheng_id={$tongchengInfo['id']}&formhash=".FORMHASH;
$ajaxZhuanfaUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=zhuanfa&tongcheng_id='.$tongcheng_id.'&formhash='.FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tongcheng:info");  




